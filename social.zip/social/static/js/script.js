// Script pour gérer les actions du tableau de bord

function showTab(tabName) {
    var tabs = document.getElementsByClassName("tab");
    for (var i = 0; i < tabs.length; i++) {
        tabs[i].style.display = "none";
    }
    document.getElementById(tabName).style.display = "block";
}

//
const lien = document.querySelector('#lien-nouvelle-categorie');
const div = document.querySelector('#nouvelle-categorie');

lien.addEventListener('click', function() {
    div.style.display = 'block';
});