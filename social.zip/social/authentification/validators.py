import re

class PasswordValidator:
    def __init__(self, min_length=8, max_length=None, require_uppercase=True, require_lowercase=True, require_number=True, require_symbol=True):
        self.min_length = min_length
        self.max_length = max_length
        self.require_uppercase = require_uppercase
        self.require_lowercase = require_lowercase
        self.require_number = require_number
        self.require_symbol = require_symbol

    def validate(self, password):
        if not self.min_length <= len(password) <= self.max_length:
            raise ValidationError('The password must be between {} and {} characters long.'.format(self.min_length, self.max_length))

        if self.require_uppercase and not re.search('[A-Z]', password):
            raise ValidationError('The password must contain at least one uppercase letter.')

        if self.require_lowercase and not re.search('[a-z]', password):
            raise ValidationError('The password must contain at least one lowercase letter.')

        if self.require_number and not re.search('[0-9]', password):
            raise ValidationError('The password must contain at least one number.')

        if self.require_symbol and not re.search('[^a-zA-Z0-9]', password):
            raise ValidationError('The password must contain at least one symbol.')

        return True

