from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import User
from .forms import LoginForm, SignupForm
from django.contrib.auth import settings
from blog.models import Article, Photo
from blog.forms import PhotoForm

def home(request):
    articles = Article.objects.all()
    nb_lectures = 0
    article_vedette = None
    for article in articles:
        if nb_lectures < article.clicks :
            nb_lectures = article.clicks
            article_vedette = article
    
    return render(request, "authentification/home.html", {"article_vedette": article_vedette})

def login_page(request):
    form = LoginForm()
    message = ""
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            #
            if user is not None:
                login(request, user)
                auteur = username
                return redirect("dashbord_page")
        message = "Identifiants invalides"
    return render(request, "authentification/login.html", {"form": form, "message": message})

@login_required
def dashbord_page(request):
    #Du même auteur
    articles = Article.objects.filter(auteur=request.user.username).reverse()
    #Compteur du nombre de fois ses articles ont été lus
    nb_lectures = 0
    for article in articles:
        nb_lectures += article.clicks
    return render(request, "authentification/dashbord.html", {"user_articles": articles, "nb_lectures": nb_lectures})

def logout_user(request):
    logout(request)
    return redirect("home")

def signup_page(request):
    form = SignupForm()
    message = ""
    if request.method == "POST":
        form = SignupForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data["username"]
            password1 = form.cleaned_data["password1"]
            password2 = form.cleaned_data["password2"]
            if password1 == password2:
                if not any(char.isalpha() for char in password1):
                    message = "Le mot de passe doit contenir au moins une lettre"
                if not any(char.isdigit() for char in password1):
                    message = "Le mot de passe doit contenir au moins un chiffre"
                if not (8 <= len(password1)):
                    message = "Le mot de passe est trop court"
                else:
                    user = User.objects.create_user(username=username, password=password1)
                    login(request, user)
                    return redirect(settings.LOGIN_REDIRECT_URL)
            else:
                message = "Les mots de passe ne correspondent pas"
    return render(request, "authentification/signup.html", {"form": form, "message": message})


@login_required
def photo_profile(request):
    form = PhotoForm()
    if request.method == "POST":
        form = PhotoForm(request.POST, request.FILES)
        if form.is_valid():
            image = form.cleaned_data["image"]
            photo = Photo(
                image=image, 
                uploader = request.user,
                caption = "Photo de profile"
            )
            photo.save()
            #Engeristre la photo
            request.user.photo = photo
            request.user.save()
            return redirect("dashbord_page")
    return render(request, "authentification/photo_profile.html", {"form": form})
