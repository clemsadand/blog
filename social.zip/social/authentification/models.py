from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from blog.models import Photo


class MyUserManager(BaseUserManager):
    def create_user(self, username, password=None):
        """
        Creates and saves a new user with the given email, username, and password.
        """

        if not username:
            raise ValueError('Users must have an username')

        user = self.model(username=username)
        user.is_staff = True
        user.is_superuser = True
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, username, password=None):
        """
        Creates and saves a new superuser with the given email, username, and password.
        """

        user = self.create_user(username, password)
        user.is_staff = False
        user.is_superuser = False
        user.save()
        return user
    
    def get_by_natural_key(self, username):
        """
        Retrieves a user by its natural key.
        """

        return self.get(username=username)

class User(AbstractBaseUser, PermissionsMixin):
    username = models.CharField(max_length=13, unique=True)
    password = models.CharField(max_length=50)
    photo = models.OneToOneField(Photo, null=True, on_delete=models.SET_NULL)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    #Because I redefine 
    objects = MyUserManager()
    #Specify username field
    USERNAME_FIELD = "username"
