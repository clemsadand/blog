from django import forms
#from django.contrib.auth.forms import UserCreationForm

#Héritage pour prendre compte les placeholder
class PlaceholderTextInput(forms.TextInput):
    def __init__(self, placeholder, **kwargs):
        super().__init__(**kwargs)
        self.attrs['placeholder'] = placeholder

class LoginForm(forms.Form):
    username = forms.CharField(max_length=13, widget=PlaceholderTextInput(placeholder="Nom d'utilisateur"))
    password = forms.CharField(max_length=50, widget=forms.PasswordInput(attrs={'placeholder': 'Mot de passe'}))

"""class SignupForm(UserCreationForm):
    pass"""

class SignupForm(forms.Form):
    username = forms.CharField(max_length=13, widget=PlaceholderTextInput(placeholder="Nom d'utilisateur"))
    password1 = forms.CharField(max_length=50, widget=forms.PasswordInput(attrs={'placeholder': 'Mot de passe'}))
    password2 = forms.CharField(max_length=50, widget=forms.PasswordInput(attrs={'placeholder': 'Confirmez mot de passe'}))


