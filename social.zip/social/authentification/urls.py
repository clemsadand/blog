from django.urls import path
from . import views

urlpatterns = [
    path("home", views.home, name="home"),
    path("login", views.login_page, name="login_page"),
    path("logout", views.logout_user, name="logout_user"),
    path("signup", views.signup_page, name="signup_page"),
    path("dashbord/", views.dashbord_page, name="dashbord_page"),
    path("profile", views.photo_profile, name="photo_profile"),
]