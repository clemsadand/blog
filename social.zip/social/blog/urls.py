#blog/urls.py
from django.urls import path
from . import views

urlpatterns = [
	path("", views.blog_page, name="blog_page"),
	path("voir_article/<id>", views.voir_article, name="voir_article"),
	path("creer_article/", views.creer_article, name="creer_article"),
	path("photo/upload/", views.photo_page, name="photo_page"),
	path("article/update/<int:article_id>", views.article_update, name="article_update"),
	path("article/delete/<int:article_id>", views.article_delete, name="article_delete"),
	path("update", views.get_update_article_id, name="get_update_article_id"),
	path("delete", views.get_delete_article_id, name="get_delete_article_id"),
	path("categorie/<int:article_id>", views.new_categorie, name="new_categorie"),
]