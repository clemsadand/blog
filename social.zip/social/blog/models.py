from django.db import models

# Create your models here.

class Categorie(models.Model):
	nom = models.CharField(max_length=60)
	
	def __str__(self):
		return self.nom

class Photo(models.Model):
	image = models.ImageField()
	caption = models.CharField(max_length=30,blank=True)
	uploader = models.CharField(max_length=30,null=True,blank=True)


class Article(models.Model):
	titre = models.CharField(max_length=60)
	auteur = models.CharField(max_length=60)
	contenu = models.TextField(blank=True)
	date = models.DateTimeField(auto_now_add=True, auto_now=False, verbose_name="Date de parution")
	categorie = models.ForeignKey(Categorie, on_delete=models.CASCADE, related_name="categories")
	clicks = models.PositiveIntegerField(default=0)
	photo = models.ForeignKey(Photo, null=True, on_delete=models.SET_NULL)

	def __str__(self):
		return self.titre

