from django.contrib import admin
from blog.models import Categorie, Article, Photo
# Register your models here.

admin.site.register(Categorie)
admin.site.register(Article)
admin.site.register(Photo)


