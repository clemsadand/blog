from django.shortcuts import render, redirect, get_object_or_404
from blog.models import Categorie, Article
from django.contrib.auth.decorators import login_required
from .forms import ArticleForm, CategorieForm, PhotoForm
from authentification.views import home
from django.views.generic import CreateView, UpdateView
# Create your views here.


def blog_page(request):
	#Récupérer tous les articles
	articles = Article.objects.all().order_by('-id')
	#
	return render(request, "blog/blog_page.html", {'tous_les_articles':articles})
	

def voir_article(request, id):
	#Récupérer tous les articles
	article = get_object_or_404(Article, id=id)
	article.clicks +=1
	article.save()
	#
	articles_du_meme_categorie = Article.objects.filter(categorie=article.categorie)
	return render(request, "blog/voir_article.html", {'article':article, "articles_du_meme_categorie": articles_du_meme_categorie})

@login_required
def creer_article(request):
	form = ArticleForm(request.POST or None)
	form2 = CategorieForm(request.POST or None)
	#
	if form.is_valid():
		titre = form.cleaned_data["titre"]
		auteur = request.user.username
		contenu = form.cleaned_data["contenu"]
		categorie = form.cleaned_data["categorie"]
		article = Article(
			titre=titre, 
			auteur=auteur, 
			categorie=categorie,
			contenu=contenu,
		)
		article.save()
	if form2.is_valid():
		form2.save()
	return render(request, "blog/creer_article.html", {"form": form, "form2": form2})

@login_required
def photo_page(request):
	form = PhotoForm()
	if request.method == "POST":
		form = PhotoForm(request.POST, request.FILES)
		if form.is_valid():
			#
			form.save()
			return redirect("home")
	return render(request, "blog/photo.html", {"form": form})


@login_required
def get_update_article_id(request):
	articles = Article.objects.filter(auteur=request.user)
	article_id = 0
	if request.method == "POST":
		article_id = request.POST["article_id"]
		return redirect("article_update", article_id=article_id)
	return render(request, "blog/get_update_article_id.html", {"article_id": article_id, "articles": articles})
	
@login_required
def article_update(request, article_id):
	#Tous les catégories
	categories = Categorie.objects.all()
	#Formulaire pour modifier l'article
	article = get_object_or_404(Article, pk=int(article_id))
	categorie = article.categorie
	#
	if request.method == "POST":
		#Get article information
		article.titre = request.POST['titre']
		article.contenu = request.POST["contenu"]
		article.auteur = request.user.username
		#Get new categorie
		categorie = Categorie.objects.get(nom=request.POST["categorie"])
		#
		article.categorie = categorie
		article.save()
	return render(request, "blog/article_update.html", {"article_id": article_id, "article": article, "categories": categories})

@login_required
def new_categorie(request, article_id):
	form = CategorieForm(request.POST or None)
	if form.is_valid():
		form.save()
		return redirect("article_update", article_id=article_id)
	return render(request, "blog/article_update.html", {"form": form})

@login_required
def get_delete_article_id(request):
	articles = Article.objects.filter(auteur=request.user)
	article_id = 0
	if request.method == "POST":
		article_id = request.POST["article_id"]
		return redirect("article_delete", article_id=article_id)
	return render(request, "blog/get_delete_article_id.html", {"article_id": article_id, "articles": articles})


@login_required
def article_delete(request, article_id):
	article = get_object_or_404(Article, pk=int(article_id))
	article.delete()
	return redirect("dashbord_page")