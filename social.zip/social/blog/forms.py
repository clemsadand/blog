from django import forms
from blog.models import Categorie, Article, Photo


class ArticleForm(forms.ModelForm):
    class Meta:
        model = Article
        fields = ("titre", "contenu", "categorie")

class CategorieForm(forms.ModelForm):
    nom = forms.CharField(max_length=60, required=False)
    
    class Meta:
        model = Categorie
        fields = ("nom",)

class PhotoForm(forms.ModelForm):
    class Meta:
        model = Photo
        fields = ("image",)